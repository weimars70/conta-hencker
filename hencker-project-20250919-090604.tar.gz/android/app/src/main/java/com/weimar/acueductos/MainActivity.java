package com.weimar.acueductos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
