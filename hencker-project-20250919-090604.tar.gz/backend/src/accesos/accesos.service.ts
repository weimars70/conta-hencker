import { Injectable } from '@nestjs/common';

@Injectable()
export class AccesosService {
  findAll() {
    return [];
  }

  findOne(id: number) {
    return {};
  }

  create(createAccesoDto: any) {
    return {};
  }

  update(id: number, updateAccesoDto: any) {
    return {};
  }

  remove(id: number) {
    return {};
  }
}