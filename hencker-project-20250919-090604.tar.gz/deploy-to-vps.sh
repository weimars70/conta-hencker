#!/bin/bash

# Script para copiar el proyecto HENCKER-SUPA-POSTGRES al VPS
# Excluye carpetas dist y node_modules para optimizar la transferencia

# Configuración del VPS
VPS_USER="weimars"  # Cambiar por tu usuario del VPS
VPS_HOST="2.58.80.90"  # Cambiar por la IP o dominio de tu VPS
VPS_PATH="/home/weimars/"  # Cambiar por la ruta destino en el VPS

# Ruta local del proyecto (formato Git Bash)
LOCAL_PATH="./"

echo "Iniciando copia del proyecto al VPS..."
echo "Origen: $LOCAL_PATH"
echo "Destino: $VPS_USER@$VPS_HOST:$VPS_PATH"
echo ""

# Crear archivo temporal excluyendo carpetas innecesarias
echo "Creando archivo temporal..."
TEMP_FILE="hencker-project-$(date +%Y%m%d-%H%M%S).tar.gz"

tar --exclude='node_modules' \
    --exclude='dist' \
    --exclude='build' \
    --exclude='.git' \
    --exclude='*.log' \
    --exclude='.env' \
    --exclude='tsconfig.*.tsbuildinfo' \
    -czf "$TEMP_FILE" .

if [ $? -eq 0 ]; then
    echo "Archivo creado: $TEMP_FILE"
    echo "Transfiriendo al VPS..."
    
    # Usar scp para transferir el archivo
    scp "$TEMP_FILE" "$VPS_USER@$VPS_HOST:$VPS_PATH"
    
    if [ $? -eq 0 ]; then
        echo "Archivo transferido exitosamente"
        echo "Descomprimiendo en el VPS..."
        
        # Conectar al VPS y descomprimir
        ssh "$VPS_USER@$VPS_HOST" "cd $VPS_PATH && tar -xzf $TEMP_FILE && rm $TEMP_FILE"
        
        # Limpiar archivo temporal local
        rm "$TEMP_FILE"
        echo "Archivo temporal local eliminado"
    else
        echo "❌ Error durante la transferencia SCP"
        rm "$TEMP_FILE"
        exit 1
    fi
else
    echo "❌ Error al crear el archivo temporal"
    exit 1
fi

echo ""
echo "✅ Despliegue completado exitosamente!"
echo "📁 Archivos desplegados en: $VPS_USER@$VPS_HOST:$VPS_PATH"
echo ""
echo "Próximos pasos en el VPS:"
echo "1. ssh $VPS_USER@$VPS_HOST"
echo "2. cd $VPS_PATH"
echo "3. npm install (en el directorio raíz y en backend/)"
echo "4. npm run build"
echo "5. Configurar variables de entorno (.env)"