<script setup lang="ts">
import EmpresasView from '../../components/empresas/EmpresasView.vue';
</script>

<template>
  <q-page padding>
    <div class="q-pa-md">
      <EmpresasView />
    </div>
  </q-page>
</template>