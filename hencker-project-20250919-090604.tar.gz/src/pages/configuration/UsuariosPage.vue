<script setup lang="ts">
import UsuariosView from '../../components/usuarios/UsuariosView.vue';
</script>

<template>
  <q-page padding>
    <div class="q-pa-md">
      <UsuariosView />
    </div>
  </q-page>
</template>